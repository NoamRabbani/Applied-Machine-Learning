# comp551_project_1
In order to use the packages TextBlob and TextSTAT, install the requirements using the following pip command:

pip install -r requirements.txt

